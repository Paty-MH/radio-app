plugins {
    id("com.android.application")
    id("kotlin-android")
    // Flutter plugin debe ir después
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.radioapp" // ✅ Este es el nombre correcto de tu paquete
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.radioapp" // ✅ Este debe coincidir con el namespace
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true // ✅ Recomendado para apps con muchas dependencias
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}
