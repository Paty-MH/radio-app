// services/audio_service.dart
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'package:just_audio_background/just_audio_background.dart';

class AudioService {
  final player = AudioPlayer();

  Future<void> init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
  }

  // Opcional: limpiar recursos en dispose
  Future<void> dispose() async {
    await player.dispose();
  }
}
