// helpers/providers/audio_provider.dart
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import '../../models/station_model.dart';
import '../../services/audio_service.dart';

class AudioProvider extends ChangeNotifier {
  final AudioService audioService;
  StationModel? _currentStation;
  String? _nowTitle; // metadatos del stream (ej. canción en curso)
  bool _isPlaying = false;

  AudioProvider(this.audioService) {
    // Listener de metadatos ICY (título de canción/programa)
    audioService.player.icyMetadataStream.listen((metadata) {
      final title = metadata?.info?.title;
      if (title != null && title.isNotEmpty) {
        _nowTitle = title;
        notifyListeners();
      }
    });

    // Listener de estado de reproducción
    audioService.player.playingStream.listen((playing) {
      _isPlaying = playing;
      notifyListeners();
    });
  }

  // Getters públicos
  StationModel? get currentStation => _currentStation;
  String? get nowTitle => _nowTitle;
  bool get isPlaying => _isPlaying;

  /// Reproduce una estación
  Future<void> play(StationModel station) async {
    try {
      _currentStation = station;
      _nowTitle = null;

      await audioService.player.setAudioSource(
        AudioSource.uri(
          Uri.parse(station.streamUrl),
          tag: MediaItem(
            id: station.id,
            album: station.acronym,
            title: station.name,
            // ⚠️ Usa una URL remota para la carátula, no asset://
            artUri: Uri.parse("https://www.radioactivatx.org/logo.png"),
          ),
        ),
        preload: true,
      );

      await audioService.player.play();
      _isPlaying = true;
      notifyListeners();
    } catch (e) {
      _isPlaying = false;
      notifyListeners();
      debugPrint('Error al reproducir: $e');
    }
  }

  /// Pausa la reproducción
  Future<void> pause() async {
    await audioService.player.pause();
    _isPlaying = false;
    notifyListeners();
  }

  /// Reanuda la reproducción
  Future<void> resume() async {
    await audioService.player.play();
    _isPlaying = true;
    notifyListeners();
  }

  /// Detiene la reproducción
  Future<void> stop() async {
    await audioService.player.stop();
    _isPlaying = false;
    _currentStation = null;
    _nowTitle = null;
    notifyListeners();
  }
}
